#!/usr/bin/env bash
set -e

./_integration-test/run.sh